window.addEvent('domready', function() {
});
