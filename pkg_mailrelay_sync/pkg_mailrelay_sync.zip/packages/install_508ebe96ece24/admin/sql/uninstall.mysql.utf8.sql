DROP TABLE IF EXISTS `#__mailrelay`;

